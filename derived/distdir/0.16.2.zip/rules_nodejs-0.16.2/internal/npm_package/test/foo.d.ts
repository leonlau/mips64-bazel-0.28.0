export const a: string;
