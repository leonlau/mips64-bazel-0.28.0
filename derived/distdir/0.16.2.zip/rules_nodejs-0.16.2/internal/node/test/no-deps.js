console.log('a node script with no npm deps');
