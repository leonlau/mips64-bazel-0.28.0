const ts = require('typescript');
console.log('a node script with a dep on typescript', ts.version);
