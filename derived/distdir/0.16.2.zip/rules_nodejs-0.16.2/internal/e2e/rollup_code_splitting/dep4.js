export function fn() {
  return 'dep4 fn';
}