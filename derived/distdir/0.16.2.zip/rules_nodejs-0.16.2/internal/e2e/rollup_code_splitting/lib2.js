export function fn() {
  return 'lib2 fn';
}