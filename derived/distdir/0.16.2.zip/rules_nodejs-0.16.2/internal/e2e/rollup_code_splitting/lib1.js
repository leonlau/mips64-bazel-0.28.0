export function fn() {
  return 'lib1 fn';
}
