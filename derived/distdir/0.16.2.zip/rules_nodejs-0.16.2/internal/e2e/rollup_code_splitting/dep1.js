export function fn() {
  return 'dep1 fn';
}