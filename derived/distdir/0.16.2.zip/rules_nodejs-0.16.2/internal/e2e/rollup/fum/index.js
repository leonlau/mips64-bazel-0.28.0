export const fum = 'Wonderland';
