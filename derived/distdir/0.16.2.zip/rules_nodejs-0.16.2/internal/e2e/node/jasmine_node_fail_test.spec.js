describe('jasmine_node_fail_test', () => {
  it('should fail', () => {expect(0).toEqual(1)});
});
