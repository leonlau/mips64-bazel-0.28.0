describe('spec in file ending with _test.js', () => {
  it('should run', () => {
    expect(true).toBe(true);
  });
});
