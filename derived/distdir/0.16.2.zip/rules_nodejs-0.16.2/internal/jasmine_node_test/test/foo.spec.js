describe('spec in file ending with .spec.js', () => {
  it('should run', () => {
    expect(true).toBe(true);
  });
});
