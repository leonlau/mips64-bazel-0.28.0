describe('spec in file ending with .test.js', () => {
  it('should run', () => {
    expect(true).toBe(true);
  });
});
