function decrement(n) {
  return n - 1;
}

exports.decrement = decrement;
