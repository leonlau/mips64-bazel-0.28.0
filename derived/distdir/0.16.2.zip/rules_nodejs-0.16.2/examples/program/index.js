function increment(n) {
  return n + 1;
}

exports.increment = increment;
