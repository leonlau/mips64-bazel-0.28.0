import {name} from './bar';

console.log(`Hello, ${name}`);
